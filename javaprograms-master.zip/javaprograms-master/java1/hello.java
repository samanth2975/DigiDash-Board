import java.lang.*;
import java.io.*;
class hello
 {
   public static void main(String a[])
     {
       int rt;
       rt=(int)Math.sqrt(Integer.parseInt(a[0])); 
       System.out.println("HELLO WORLD(DOT)\nI AM CHITTI, THE ROBOT(DOT)"+rt);
      }
 }